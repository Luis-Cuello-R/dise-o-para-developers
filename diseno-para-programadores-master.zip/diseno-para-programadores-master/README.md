# Diseño para programadores.
Bienvenido al curso de diseño para programadores. En este repositorio
encontrarás el material del curso diseño para programadores.

## Brief.
En la carpeta brief encontrarás el ejemplo de brief que vimos en clase,
úsalo como inspiración para crear el brief de tu proyecto.

## User flows.
En la carpeta user flows encontrarás el ejemplo de site map que creamos
en clase y también el ejemplo de user flow para realizar un pedido.

## Wireframes.
En la carpeta wireframes encontrarás el ejemplo de wireframes que creamos
para la aplicación de nuestro curso.

## App.
En la carpeta App encontrarás la aplicación en React.js que creamos para
la aplicación de nuestro curso. Si necesitas más información sobre el
código puedes encontrarla en el README.md dentro de esa carpeta.